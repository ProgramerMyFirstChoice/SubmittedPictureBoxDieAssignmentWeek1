﻿namespace DieDisplayImage3
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnDisplayDice = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDiceNumber = new System.Windows.Forms.TextBox();
            this.pictureBoxDiceImage = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDiceImage)).BeginInit();
            this.SuspendLayout();
            // 
            // btnDisplayDice
            // 
            this.btnDisplayDice.Location = new System.Drawing.Point(14, 167);
            this.btnDisplayDice.Margin = new System.Windows.Forms.Padding(5);
            this.btnDisplayDice.Name = "btnDisplayDice";
            this.btnDisplayDice.Size = new System.Drawing.Size(125, 35);
            this.btnDisplayDice.TabIndex = 0;
            this.btnDisplayDice.Text = "Display Dice";
            this.btnDisplayDice.UseVisualStyleBackColor = true;
            this.btnDisplayDice.Click += new System.EventHandler(this.btnDisplayDice_Click_1);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(159, 167);
            this.btnExit.Margin = new System.Windows.Forms.Padding(5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(90, 35);
            this.btnExit.TabIndex = 1;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click_1);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(59, 29);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(168, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Rolled Dice Number";
            // 
            // txtDiceNumber
            // 
            this.txtDiceNumber.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiceNumber.Location = new System.Drawing.Point(14, 69);
            this.txtDiceNumber.Margin = new System.Windows.Forms.Padding(5);
            this.txtDiceNumber.Name = "txtDiceNumber";
            this.txtDiceNumber.Size = new System.Drawing.Size(122, 31);
            this.txtDiceNumber.TabIndex = 4;
            this.txtDiceNumber.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureBoxDiceImage
            // 
            
            this.pictureBoxDiceImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pictureBoxDiceImage.Location = new System.Drawing.Point(171, 69);
            this.pictureBoxDiceImage.Margin = new System.Windows.Forms.Padding(5);
            this.pictureBoxDiceImage.Name = "pictureBoxDiceImage";
            this.pictureBoxDiceImage.Size = new System.Drawing.Size(60, 54);
            this.pictureBoxDiceImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureBoxDiceImage.TabIndex = 3;
            this.pictureBoxDiceImage.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(268, 221);
            this.Controls.Add(this.txtDiceNumber);
            this.Controls.Add(this.pictureBoxDiceImage);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDisplayDice);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxDiceImage)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnDisplayDice;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBoxDiceImage;
        private System.Windows.Forms.TextBox txtDiceNumber;
    }
}

