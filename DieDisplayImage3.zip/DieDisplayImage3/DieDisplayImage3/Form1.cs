﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DieDisplayImage3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        // Create A Random Number object
        Random randomNumber = new Random();

        Image[] die = new Image[6];

        private void btnDisplayDice_Click_1(object sender, EventArgs e)
        {
            for (int i = 0; i < die.Length; i++)
            {
                // Assign the image from the resource to the array based on the random number

                die[i] = Image.FromFile(@"C:\Users\Programmer\Documents\visual studio 2017\Projects\DieDisplayImage3\DieDisplayImage3\Resources\die" + i + ".gif");

                // Generate random number using Next() Method in the random object
                // in the range of 1 to 6
                int index = randomNumber.Next(1, 6 + 1);

                // Display the image from the array to the picture box 
                pictureBoxDiceImage.Image = die[index - 1];

                // Assign the number generated to text box
                txtDiceNumber.Text = (index).ToString();
            }
        }

        private void btnExit_Click_1(object sender, EventArgs e)
        {
            // Close this form
            this.Close();
        }

    }
}
