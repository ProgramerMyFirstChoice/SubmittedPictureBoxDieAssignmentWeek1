﻿namespace DiesImageDisplay
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnDisplayDice = new System.Windows.Forms.Button();
            this.btnExit = new System.Windows.Forms.Button();
            this.txtDiceValue = new System.Windows.Forms.TextBox();
            this.pictureDice = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureDice)).BeginInit();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(20, 37);
            this.label1.Margin = new System.Windows.Forms.Padding(5, 0, 5, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(189, 20);
            this.label1.TabIndex = 0;
            this.label1.Text = "Random Value of Dice";
            // 
            // btnDisplayDice
            // 
            this.btnDisplayDice.Location = new System.Drawing.Point(14, 156);
            this.btnDisplayDice.Margin = new System.Windows.Forms.Padding(5);
            this.btnDisplayDice.Name = "btnDisplayDice";
            this.btnDisplayDice.Size = new System.Drawing.Size(132, 34);
            this.btnDisplayDice.TabIndex = 2;
            this.btnDisplayDice.Text = "Display Dice";
            this.btnDisplayDice.UseVisualStyleBackColor = true;
            this.btnDisplayDice.Click += new System.EventHandler(this.btnDisplayDice_Click);
            // 
            // btnExit
            // 
            this.btnExit.Location = new System.Drawing.Point(157, 156);
            this.btnExit.Margin = new System.Windows.Forms.Padding(5);
            this.btnExit.Name = "btnExit";
            this.btnExit.Size = new System.Drawing.Size(84, 34);
            this.btnExit.TabIndex = 3;
            this.btnExit.Text = "Exit";
            this.btnExit.UseVisualStyleBackColor = true;
            this.btnExit.Click += new System.EventHandler(this.btnExit_Click);
            // 
            // txtDiceValue
            // 
            this.txtDiceValue.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtDiceValue.Location = new System.Drawing.Point(14, 72);
            this.txtDiceValue.Margin = new System.Windows.Forms.Padding(5);
            this.txtDiceValue.Name = "txtDiceValue";
            this.txtDiceValue.Size = new System.Drawing.Size(138, 31);
            this.txtDiceValue.TabIndex = 4;
            this.txtDiceValue.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // pictureDice
            // 
            this.pictureDice.BackgroundImage = global::DiesImageDisplay.Properties.Resources.RollingDiesImage;
            this.pictureDice.Location = new System.Drawing.Point(181, 72);
            this.pictureDice.Margin = new System.Windows.Forms.Padding(5);
            this.pictureDice.Name = "pictureDice";
            this.pictureDice.Size = new System.Drawing.Size(60, 54);
            this.pictureDice.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pictureDice.TabIndex = 1;
            this.pictureDice.TabStop = false;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(10F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.ClientSize = new System.Drawing.Size(257, 215);
            this.Controls.Add(this.txtDiceValue);
            this.Controls.Add(this.btnExit);
            this.Controls.Add(this.btnDisplayDice);
            this.Controls.Add(this.pictureDice);
            this.Controls.Add(this.label1);
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.Margin = new System.Windows.Forms.Padding(5);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Dice Generator";
            ((System.ComponentModel.ISupportInitialize)(this.pictureDice)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureDice;
        private System.Windows.Forms.Button btnDisplayDice;
        private System.Windows.Forms.Button btnExit;
        private System.Windows.Forms.TextBox txtDiceValue;
    }
}

