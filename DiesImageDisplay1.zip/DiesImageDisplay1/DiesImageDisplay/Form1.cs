﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DiesImageDisplay
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnDisplayDice_Click(object sender, EventArgs e)
        {
            // Create A Random Number object

            Random randomNumber = new Random();

            // Generate random using Next() Method in the random object
            // in the range of 1 to 6

            int randomNumberOfDice = randomNumber.Next(1, 7);

            // Assign the number generated to text box

            txtDiceValue.Text = randomNumberOfDice.ToString();

            // Check the the generated random number and display the image to
            // Picturebox according to the random number
            switch (randomNumberOfDice)
            {
                case 1:
                    this.pictureDice.ImageLocation = "C:\\Users\\Programmer\\Documents\\die1.gif";
                    break;
                case 2:
                    this.pictureDice.ImageLocation = "C:\\Users\\Programmer\\Documents\\die2.gif";
                    break;
                case 3:
                    this.pictureDice.ImageLocation = "C:\\Users\\Programmer\\Documents\\die3.gif";
                    break;
                case 4:
                    this.pictureDice.ImageLocation = "C:\\Users\\Programmer\\Documents\\die4.gif";
                    break;
                case 5:
                    this.pictureDice.ImageLocation = "C:\\Users\\Programmer\\Documents\\die5.gif";
                    break;
                case 6:
                    this.pictureDice.ImageLocation = "C:\\Users\\Programmer\\Documents\\die6.gif";
                    break;
            }

        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            // Close the form
            this.Close();
        }
    }
}
